#ifndef ESPRESSO_BASED_H
#define ESPRESSO_BASED_H

#include <vector>
#include <string>
#include <numeric>

#include "ingredient.h"

class EspressoBased {
public:
    std::string get_name();
    double price();
    std::vector<Ingredient*>& get_ingredients();

    [[maybe_unused]] void brew() {}

    virtual ~EspressoBased();

protected:
    EspressoBased() = default;
    EspressoBased(const EspressoBased& other);
    void operator=(const EspressoBased& other);

    std::vector<Ingredient*> ingredients;
    std::string name;
};

#endif // ESPRESSO_BASED_H