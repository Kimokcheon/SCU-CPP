#ifndef INGREDIENT_H
#define INGREDIENT_H

#include <string>

class Ingredient
{
public:
    double get_price_unit() { return price_unit; }
    size_t get_units() { return units; }
    virtual std::string get_name() = 0;

    double price() { return price_unit * units; }

    virtual ~Ingredient() = default;
    virtual Ingredient* clone() const = 0;

protected:
    Ingredient(double price_unit, size_t units) {
        this->price_unit = price_unit;
        this->units = units;
    }

    Ingredient() = default;
    Ingredient(const Ingredient& other) = default;
    Ingredient& operator=(const Ingredient& other) = default;

    double price_unit = -1;
    size_t units = -1;
    std::string name = "Unspecified";
};

#endif // INGREDIENT_H