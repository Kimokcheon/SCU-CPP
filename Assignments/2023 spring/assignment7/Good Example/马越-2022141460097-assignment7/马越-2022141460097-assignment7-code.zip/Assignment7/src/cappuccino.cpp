#include "cappuccino.h"

Cappuccino::Cappuccino(): EspressoBased() {
    name = "Cappuccino";
    ingredients = {
            new Espresso(2),
            new Milk(2),
            new MilkFoam(1),
    };
}

Cappuccino::Cappuccino(const Cappuccino &other): EspressoBased(other) {
    for (const auto &item: other.side_items)
        side_items.push_back(item->clone());
}

Cappuccino::~Cappuccino() {
    for (auto& ingredient: ingredients)
        delete ingredient;
    ingredients.clear();
    side_items.clear();
}

void Cappuccino::operator=(const Cappuccino &other) {
    if (this == &other)
        return;
    for (auto &item : side_items)
        delete item;
    side_items.clear();
    side_items.reserve(other.side_items.size());
    for (const auto &item : other.side_items)
        side_items.push_back(item->clone());
}

void Cappuccino::add_side_item(Ingredient *side) {
    ingredients.push_back(side);
    side_items.push_back(side);
}

std::vector<Ingredient *> &Cappuccino::get_side_items() {
    return side_items;
}



