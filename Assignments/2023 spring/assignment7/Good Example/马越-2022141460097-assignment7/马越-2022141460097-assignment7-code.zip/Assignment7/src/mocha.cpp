#include "mocha.h"

Mocha::Mocha(): EspressoBased() {
    name = "Mocha";
    ingredients = {
            new Espresso(2),
            new Milk(2),
            new MilkFoam(1),
            new Chocolate(1),
    };
}

Mocha::Mocha(const Mocha &other): EspressoBased(other) {
    for (const auto &item: other.side_items)
        side_items.push_back(item->clone());
}

Mocha::~Mocha() {
    for (auto& ingredient: ingredients)
        delete ingredient;
    ingredients.clear();
    side_items.clear();
}

void Mocha::operator=(const Mocha &other) {
    if (this == &other)
        return;
    for (auto &item : side_items)
        delete item;
    side_items.clear();
    side_items.reserve(other.side_items.size());
    for (const auto &item : other.side_items)
        side_items.push_back(item->clone());
}

void Mocha::add_side_item(Ingredient *side) {
    ingredients.push_back(side);
    side_items.push_back(side);
}

std::vector<Ingredient *> &Mocha::get_side_items() {
    return side_items;
}
