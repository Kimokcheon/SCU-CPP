#include "espresso_based.h"

EspressoBased::~EspressoBased() {
    for (auto& ingredient: ingredients)
        delete ingredient;
    ingredients.clear();
}

std::vector<Ingredient *>& EspressoBased::get_ingredients() {
    return ingredients;
}

EspressoBased::EspressoBased(const EspressoBased &other) {
    name = other.name;
    for(const auto& ingredient : other.ingredients)
        ingredients.push_back(ingredient->clone());
}

void EspressoBased::operator=(const EspressoBased &other) {
    if (this == &other)
        return;
    for (auto& ingredient: ingredients)
        delete ingredient;
    ingredients.clear();
    ingredients.reserve(other.ingredients.size());
    for(const auto& ingredient : other.ingredients)
        ingredients.push_back(ingredient->clone());
}

double EspressoBased::price() {
    return std::accumulate(ingredients.begin(), ingredients.end(), 0.0,
                           [](double sum, Ingredient* i) { return sum + i->price(); });
}

std::string EspressoBased::get_name() {
    return name;
}