#include <iostream>
#include <string>
#include <vector>
#include <algorithm>
using namespace std;

class BigDecimal {
public:
    BigDecimal() : BigDecimal("0") {}
    BigDecimal(string s) {
        if (s[0] == '-') {
            sign = -1;
            s.erase(0, 1);
        }
        if (s[s.size() - 1] == '.') {
            decimal = true;
            s.erase(s.size() - 1, 1);
        }
        int pos = s.find('.');
        if (pos != string::npos) {
            decimal = true;
            s.erase(pos, 1);
            dot = s.size() - pos;
        }
        reverse(s.begin(), s.end());
        for (int i = 0; i < s.size(); i++)
            digits.push_back(s[i] - '0');
    }
    BigDecimal operator + (const BigDecimal& b) const {
        BigDecimal res;
        res.digits.clear();
        int carry = 0;
        int len = max(digits.size(), b.digits.size());
        res.sign = sign;
        res.decimal = decimal || b.decimal;
        res.dot = max(dot, b.dot);
        res.digits.resize(len);
        for (int i = 0; i < len; i++) {
            int x = (i < digits.size() ? digits[i] : 0);
            int y = (i < b.digits.size() ? b.digits[i] : 0);
            int sum = x + y + carry;
            res.digits[i] = sum % 10;
            carry = sum / 10;
        }
        if (carry) res.digits.push_back(carry);
        return res;
    }
    BigDecimal operator - (const BigDecimal& b) const {
        BigDecimal res;
        res.digits.clear();
        int borrow = 0;
        int len = max(digits.size(), b.digits.size());
        if (*this < b) { // 如果被减数小于减数，则交换它们并将结果的符号设为负数
            res.sign = -1;
            res.decimal = decimal || b.decimal;
            res.dot = max(dot, b.dot);
            res.digits.resize(len);
            for (int i = 0; i < len; i++) {
                int x = (i < b.digits.size() ? b.digits[i] : 0);
                int y = (i < digits.size() ? digits[i] : 0);
                int diff = x - y - borrow;
                if (diff < 0) {
                    diff += 10;
                    borrow = 1;
                } else {
                    borrow = 0;
                }
                res.digits[i] = diff;
            }
        } else {
            res.sign = sign;
            res.decimal = decimal || b.decimal;
            res.dot = max(dot, b.dot);
            res.digits.resize(len);
            for (int i = 0; i < len; i++) {
                int x = (i < digits.size() ? digits[i] : 0);
                int y = (i < b.digits.size() ? b.digits[i] : 0);
                int diff = x - y - borrow;
                if (diff < 0) {
                    diff += 10;
                    borrow = 1;
                } else {
                    borrow = 0;
                }
                res.digits[i] = diff;
            }
        }
        while (res.digits.size() > 1 && res.digits.back() == 0)
            res.digits.pop_back();
        return res;
    }
    BigDecimal operator * (const BigDecimal& b) const {
        BigDecimal res;
        res.digits.resize(digits.size() + b.digits.size());
        for (int i = 0; i < digits.size(); i++) {
            for (int j = 0; j < b.digits.size(); j++) {
                res.digits[i+j] += digits[i] * b.digits[j];
                res.digits[i+j+1] += res.digits[i+j] / 10;
                res.digits[i+j] %= 10;
            }
        }
        res.sign = sign * b.sign;
        if (decimal || b.decimal) res.decimal = true;
        res.dot = dot + b.dot;
        while (res.digits.size() > 1 && res.digits.back() == 0)
            res.digits.pop_back();
        return res;
    }

    bool operator < (const BigDecimal& b) const {
        if (sign != b.sign) return sign < b.sign;
        if (digits.size() != b.digits.size()) {
            if (sign == 1) return digits.size() < b.digits.size();
            else return digits.size() > b.digits.size();
        }
        for (int i = digits.size() - 1; i >= 0; i--) {
            if (digits[i] != b.digits[i]) {
                if (sign == 1) return digits[i] < b.digits[i];
                else return digits[i] > b.digits[i];
            }
        }
        return false;
    }
    bool operator == (const BigDecimal& b) const {
        return sign == b.sign && digits == b.digits && decimal == b.decimal && dot == b.dot;
    }
    bool operator > (const BigDecimal& b) const {
        return !(*this < b) && !(*this == b);
    }
    bool operator <= (const BigDecimal& b) const {
        return (*this < b) || (*this == b);
    }
    bool operator >= (const BigDecimal& b) const {
        return !(*this < b);
    }
    friend ostream& operator << (ostream& out, const BigDecimal& x) {
        if (x.sign == -1) out << '-';
        for (int i = x.digits.size() - 1; i >= 0; i--) {
            out << x.digits[i];
            if (i == x.dot && x.dot != 0 && x.decimal) out << '.';
        }
        if (x.dot > x.digits.size()) {
            for (int i = 0; i < x.dot - x.digits.size(); i++)
                out << '0';
        }
        if (x.digits.empty()) out << '0';
        return out;
    }
    friend istream& operator >> (istream& in, BigDecimal& x) {
        string s;
        in >> s;
        x.digits.clear();
        x.sign = 1;
        x.dot = 0;
        x.decimal = false;
        if (s[0] == '-') {
            x.sign = -1;
            s = s.substr(1);
        }
        for (int i = s.size() - 1; i >= 0;i--) {
                if (s[i] == '.') {
                    x.dot = s.size() - i - 1;
                    x.decimal = true;
                } else {
                    x.digits.push_back(s[i] - '0');
                }
            }
        while (x.digits.size() > 1 && x.digits.back() == 0)
            x.digits.pop_back();
        return in;
    }
private:
    vector<int> digits;
    int sign;
    int dot;
    bool decimal;
};
int main()
{
    BigDecimal a, b;
    cin >> a >> b;
    cout<<a<<" + "<<b<<" = "<< a + b << endl;
    cout<<a<<" - "<<b<<" = "<< a - b << endl;
    cout<<a<<" * "<<b<<" = "<< a * b << endl;


    return 0;
}
