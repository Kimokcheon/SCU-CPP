#ifndef CALCULATOR_H
#define CALCULATOR_H
#include <iostream>
#include <string>
#include <stack>
#include <cmath>
#include <vector>
using namespace std;
class Calculator
{
public:
    static constexpr double PI = 3.14159265358979323846;
    static constexpr double E =  2.71828182845904523536;
    void mathfuction(string &str);
    bool Isdigital(char c);
    bool IsSymbol(char c);
    bool IsSymbol1(char c);
    bool Isword(char c);
    bool Symbolnum(string s);
    void preprocessing();
    void Formatting();
    int getPri(char c);
    void getPostfix();
    void CalcResult();
    double calc(Calculator &cal);
    double calc1(Calculator &cal);
    string Input;
    string OperateSymbol;
private:
    vector <string> OperateFigure;
    string CustomizedSymbolInput;
    stack<char> SymbolStack;
    stack<double> FigureStack;
    double result;
};
#endif // CALCULATOR_H
