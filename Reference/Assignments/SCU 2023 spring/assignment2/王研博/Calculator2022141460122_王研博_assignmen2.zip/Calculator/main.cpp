#include "calculator.h"
int main() {
    Calculator cal;
    cout<< "Please input the expression you want to calculate: " << endl;
    while(1)
    {
        cout << cal.calc(cal) << endl;
        cout<< "Please input the expression you want to calculate: " << endl;
    }
    return 0;
}
