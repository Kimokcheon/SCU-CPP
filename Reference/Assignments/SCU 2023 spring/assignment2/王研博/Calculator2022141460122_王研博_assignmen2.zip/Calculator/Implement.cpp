#include "calculator.h"
bool Calculator::Symbolnum(string s)
{
    int cnt1 = 0, cnt2 = 0;
    int pos = 0;
    while(s.find('(', pos) != -1)
    {
        pos = s.find('(', pos + 1);
        cnt1++;
    }
    pos = 0;
    while(s.find(')', pos) != -1)
    {
        pos = s.find(')', pos + 1);
        cnt2++;
    }
    if(cnt1 == cnt2)
        return true;
    else
        return false;

}
bool Calculator::IsSymbol1(char c)
{
    if(c == '+' || c == '-' || c == '*' || c == '/' )
        return true;
    else
        return false;
}
bool Calculator::Isdigital(char c)
{
    if(c >= '0' && c <= '9')
        return true;
    else
        return false;
}
bool Calculator::IsSymbol(char c)
{
    if(c == '+' || c == '-' || c == '*' || c == '/' || c == '(' || c == ')')
        return true;
    else
        return false;
}
bool Calculator::Isword(char c)
{
    if((int)c > 64 && (int)c < 91 || (int)c > 96 && (int)c < 123)
        return true;
    else
        return false;
}
void Calculator::mathfuction(string &str)
{
    while(str.find(' ') != -1)
    {
        int pos = str.find(' ');
        str.erase(pos, 1);
    }
    if(str.find('/') != -1)
    {
        int pos1 = str.find('/');
        if(str[pos1 + 1] == '0')
        {
            cout << "#INFINITE" << endl;
            exit(0);
        }
    }

    if(str.find("PI") != -1)
    {
        int pos1 = str.find("PI");
        str.replace(pos1, 2, to_string(3.14159265358979323846));
    }
    if(str.find("E") != -1)
    {
        int pos1 = str.find("E");
        str.replace(pos1, 1, to_string(2.71828182845904523536));
    }
    if(str.find("sin(") != -1)
    {
        int pos1 = str.find("sin(");
        int pos2 = str.find(")", pos1);
        string num = str.substr(pos1 + 4, pos2);
        Calculator cal;
        cal.Input = num;
        mathfuction(cal.Input);
        cal.calc1(cal);
        double n = cal.result;
        n = sin(n);
        str.replace(pos1, pos2 - pos1 + 1, to_string(n));
    }
    if(str.find("cos(") != -1)
    {
        int pos1 = str.find("cos(");
        int pos2 = str.find(")", pos1);
        string num = str.substr(pos1 + 4, pos2);
        Calculator cal;
        cal.Input = num;
        mathfuction(cal.Input);
        cal.calc1(cal);
        double n = cal.result;
        n = cos(n);
        str.replace(pos1, pos2 - pos1 + 1, to_string(n));
    }
    if(str.find("tan(") != -1)
    {
        int pos1 = str.find("tan(");
        int pos2 = str.find(")", pos1);
        string num = str.substr(pos1 + 4, pos2);
        Calculator cal;
        cal.Input = num;
        mathfuction(cal.Input);
        cal.calc1(cal);
        double n = cal.result;
        n = tan(n);
        str.replace(pos1, pos2 - pos1 + 1, to_string(n));
    }
    if(str.find("log(") != -1)
    {
        int pos1 = str.find("log(");
        int pos2 = str.find(")", pos1);
        string num = str.substr(pos1 + 4, pos2);
        Calculator cal;
        cal.Input = num;
        mathfuction(cal.Input);
        cal.calc1(cal);
        double n = cal.result;
        n = log10(n);
        str.replace(pos1, pos2 - pos1 + 1, to_string(n));
    }
    if(str.find("ln(") != -1)
    {
        int pos1 = str.find("ln(");
        int pos2 = str.find(")", pos1);
        string num = str.substr(pos1 + 3, pos2);
        Calculator cal;
        cal.Input = num;
        mathfuction(cal.Input);
        cal.calc1(cal);
        double n = cal.result;
        n = log(n);
        str.replace(pos1, pos2 - pos1 + 1, to_string(n));
    }
    if(str.find("sqrt(") != -1)
    {
        int pos1 = str.find("sqrt(");
        int pos2 = str.find(")", pos1);
        string num = str.substr(pos1 + 5, pos2);
        Calculator cal;
        cal.Input = num;
        mathfuction(cal.Input);
        cal.calc1(cal);
        double n = cal.result;
        n = sqrt(n);
        str.replace(pos1, pos2 - pos1 + 1, to_string(n));
    }
    if(str.find("pow(") != -1)
    {
        int pos1 = str.find("pow(");
        int pos2 = str.find(",", pos1);
        int pos3 = str.find(")", pos2);
        string num1 = str.substr(pos1 + 4, pos2 - pos1 - 4);
        string num2 = str.substr(pos2 + 1, pos3 - pos2 - 1);
        double n1 = stod(num1);
        double n2 = stod(num2);
        n1 = pow(n1, n2);
        str.replace(pos1, pos3 - pos1 + 1, to_string(n1));
    }
    if(str.find("abs(") != -1)
    {
        int pos1 = str.find("abs(");
        int pos2 = str.find(")", pos1);
        string num = str.substr(pos1 + 4, pos2);
        double n = stod(num);
        n = abs(n);
        str.replace(pos1, pos2 - pos1 + 1, to_string(n));
    }
    if(str.find("max") != -1)
    {
        int pos1 = str.find("max");
        int pos2 = str.find(",", pos1);
        int pos3 = str.find(")", pos2);
        string num1 = str.substr(pos1 + 4, pos2 - pos1 - 4);
        string num2 = str.substr(pos2 + 1, pos3 - pos2 - 1);
        double n1 = stod(num1);
        double n2 = stod(num2);
        n1 = max(n1, n2);
        str.replace(pos1, pos3 - pos1 + 1, to_string(n1));
    }
    if(str.find("min") != -1)
    {
        int pos1 = str.find("min");
        int pos2 = str.find(",", pos1);
        int pos3 = str.find(")", pos2);
        string num1 = str.substr(pos1 + 4, pos2 - pos1 - 4);
        string num2 = str.substr(pos2 + 1, pos3 - pos2 - 1);
        double n1 = stod(num1);
        double n2 = stod(num2);
        n1 = min(n1, n2);
        str.replace(pos1, pos3 - pos1 + 1, to_string(n1));
    }
    if(str.find("exp") != -1)
    {
        int pos1 = str.find("exp");
        int pos2 = str.find(")", pos1);
        string num = str.substr(pos1 + 4, pos2);
        double n = stod(num);
        n = exp(n);
        str.replace(pos1, pos2 - pos1 + 1, to_string(n));
    }
    for(int i = 0; i < str.size(); i++)
    {
        if(Isword(str[i]))
        {
            cout<<"The variable does not exist!"<<endl;
            exit(0);
        }
        if(IsSymbol1(str[i]) && i != 0)
        {
            if(IsSymbol1(str[i - 1]))
            {
                cout<<"The input is wrong!"<<endl;
                exit(0);
            }
        }
    }
    return;
}
void Calculator::preprocessing()
{
    vector<pair<string, double>> v;
    string temp;
    getline(cin, temp);
    if(temp.find('=') == -1)
    {
        mathfuction(temp);
        Input = temp;
        if(!Symbolnum(Input))
        {
            cout<<"The bracket is not matching!"<<endl;
            exit(0);
        }
        return;
    }
    while(temp.find('=') != -1)
    {
        int pos = temp.find('=');
        string name = temp.substr(0, pos);
        for(int i = 0; i < name.size(); i++)
        {
            if(name[i] == ' ')
            {
                name.erase(i, 1);
                i--;
            }
        }
        string value = temp.substr(pos + 1, temp.size() - pos - 1);
        for(int i = 0; i < value.size(); i++)
        {
            if(value[i] == ' ')
            {
                value.erase(i, 1);
                i--;
            }
        }
        if(!Isword(name[0]) && name[0] != '_')
        {
            cout << "The variable name is not valid!" << endl;
            exit(0);
        }
        if(value.find("PI") != -1)
        {
            value.replace(value.find("PI"), 2, to_string(3.14159265358979323846));
        }
        if(value.find("E") != -1)
        {
            value.replace(value.find("E"), 1, to_string(2.71828182845904523536));
        }
        Calculator cal;
        cal.Input = value;
        mathfuction(cal.Input);
        double num = cal.calc1(cal);
        if(name == "PI" && num != 3.14159265358979323846)
        {
            cout << "This is const value! Can not be changed!"<< endl;
            exit(0);
        }
        if(name == "E" && num != 2.71828182845904523536)
        {
            cout << "This is const value! Can not be changed!"<< endl;
            exit(0);
        }
        v.push_back(make_pair(name, num));
        getline(cin, temp);
        for(int i = 0; i < temp.size(); i++)
        {
            if(temp[i] == ' ')
            {
                temp.erase(i, 1);
                i--;
            }
        }
    }
    for(auto i = 0; i < v.size(); i++)
    {
        int pos = 0;
        while(temp.find(v[i].first, pos) != -1)
        {
            pos = temp.find(v[i].first, pos);
            if(IsSymbol(temp[pos - 1]) && IsSymbol(temp[pos + v[i].first.size()]) || pos == 0 && IsSymbol(temp[pos + v[i].first.size()]) || pos + v[i].first.size() == temp.size() && IsSymbol(temp[pos - 1]))
            {
                if(v[i].second < 0)
                {
                    temp.replace(pos, v[i].first.size(), "(" + to_string(v[i].second) + ")");
                }
                else
                {
                    temp.replace(pos, v[i].first.size(), to_string(v[i].second));
                }
            }
            pos = temp.find(v[i].first, pos + 1);
        }
    }
    if(!Symbolnum(temp))
    {
        cout<<"The bracket is not matching!"<<endl;
        exit(0);
    }
    mathfuction(temp);
    Input = temp;
}
void Calculator::Formatting()
{
    CustomizedSymbolInput = Input;
    for (auto i = 0; i < CustomizedSymbolInput.size(); i++)
    {
        if(CustomizedSymbolInput[i] == '+' || CustomizedSymbolInput[i] == '-')
        {
            if(i == 0)
            {
                CustomizedSymbolInput.insert(0, 1, '0');
            }
            else if(CustomizedSymbolInput[i - 1] == '(')
            {
                CustomizedSymbolInput.insert(i, 1, '0');
            }
        }
    }
}
int Calculator::getPri(char c)
{
    if(c == '+' || c == '-')
        return 1;
    else if(c == '*' || c == '/')
        return 2;
    else if(c == '^')
        return 3;
    else
        return 0;
}
void Calculator::getPostfix()
{
    string temp;
    for(auto i = 0; i < CustomizedSymbolInput.size(); i++)
    {
        temp = "";
        switch (CustomizedSymbolInput[i])
        {
            case '+':
            case '-':
            case '*':
            case '/':
            case '^':
                if(SymbolStack.empty())
                {
                    SymbolStack.push(CustomizedSymbolInput[i]);
                }
                else
                {
                    while(!SymbolStack.empty() && getPri(SymbolStack.top()) >= getPri(CustomizedSymbolInput[i]))
                    {
                        temp += SymbolStack.top();
                        OperateFigure.push_back(temp);
                        SymbolStack.pop();
                        temp = "";
                    }
                    SymbolStack.push(CustomizedSymbolInput[i]);
                }
                break;
            case '(':
                SymbolStack.push(CustomizedSymbolInput[i]);
                break;
            case ')':
                while(!SymbolStack.empty() && SymbolStack.top() != '(')
                {
                    temp += SymbolStack.top();
                    OperateFigure.push_back(temp);
                    SymbolStack.pop();
                    temp = "";
                }
                if(!SymbolStack.empty() && SymbolStack.top() == '(')
                {
                    SymbolStack.pop();
                }
                break;
            default:
                if(CustomizedSymbolInput[i] >= '0' && CustomizedSymbolInput[i] <= '9')
                {
                    temp += CustomizedSymbolInput[i];
                    while((CustomizedSymbolInput[i + 1] >= '0' && CustomizedSymbolInput[i + 1] <= '9' || CustomizedSymbolInput[i + 1] == '.') &&
                          i + 1 < CustomizedSymbolInput.size())
                    {
                        temp += CustomizedSymbolInput[i + 1];
                        i++;
                    }
                    if(temp[temp.size() - 1] == '.')
                    {
                        temp += '0';
                    }
                    OperateFigure.push_back(temp);
                }
                break;
        }
    }
    while(!SymbolStack.empty())
    {
        temp = "";
        temp += SymbolStack.top();
        OperateFigure.push_back(temp);
        SymbolStack.pop();
    }
}
void Calculator::CalcResult()
{
    string temp;
//    {
//        cout<< *it << " ";
//    }
    double number, op1, op2;
    for(auto i = 0; i < OperateFigure.size(); i++)
    {
        temp = OperateFigure[i];
        if(temp[0] <= '9' && temp[0] >= '0')
        {
            number = atof(temp.c_str());
            FigureStack.push(number);
        }
        else if(OperateFigure[i] == "+")
        {
            if(!FigureStack.empty())
            {
                op2 = FigureStack.top();
                FigureStack.pop();
            }
            if(!FigureStack.empty())
            {
                op1 = FigureStack.top();
                FigureStack.pop();
            }
            FigureStack.push(op1 + op2);
        }
        else if(OperateFigure[i] == "-")
        {
            if(!FigureStack.empty())
            {
                op2 = FigureStack.top();
                FigureStack.pop();
            }
            if(!FigureStack.empty())
            {
                op1 = FigureStack.top();
                FigureStack.pop();
            }
            FigureStack.push(op1 - op2);
        }
        else if(OperateFigure[i] == "*")
        {
            if(!FigureStack.empty())
            {
                op2 = FigureStack.top();
                FigureStack.pop();
            }
            if(!FigureStack.empty())
            {
                op1 = FigureStack.top();
                FigureStack.pop();
            }
            FigureStack.push(op1 * op2);
        }
        else if(OperateFigure[i] == "/")
        {
            if(!FigureStack.empty())
            {
                op2 = FigureStack.top();
                FigureStack.pop();
            }
            if(!FigureStack.empty())
            {
                op1 = FigureStack.top();
                FigureStack.pop();
            }
            FigureStack.push(op1 / op2);
        }
        else if(OperateFigure[i] == "^")
        {
            if(!FigureStack.empty())
            {
                op2 = FigureStack.top();
                FigureStack.pop();
            }
            if(!FigureStack.empty())
            {
                op1 = FigureStack.top();
                FigureStack.pop();
            }
            FigureStack.push(pow(op1, op2));
        }
    }
    if(!FigureStack.empty())
    {
        result = FigureStack.top();
        FigureStack.pop();
    }
}
double Calculator::calc(Calculator &cal)
{
    cal.preprocessing();
    cal.Formatting();
    cal.getPostfix();
    cal.CalcResult();
    return cal.result;
}
double Calculator::calc1(Calculator &cal)
{
    cal.Formatting();
    cal.getPostfix();
    cal.CalcResult();
    return cal.result;
}