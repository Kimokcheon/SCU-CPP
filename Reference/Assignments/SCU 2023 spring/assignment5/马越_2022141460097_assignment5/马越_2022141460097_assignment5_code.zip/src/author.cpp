#include "author.h"

Author::Author(std::string _name) : Base(std::move(_name)) { }
