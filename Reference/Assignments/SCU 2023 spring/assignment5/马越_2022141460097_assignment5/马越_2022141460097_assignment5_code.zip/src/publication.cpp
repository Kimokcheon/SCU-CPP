#include "publication.h"

Publisher::Publisher(std::string _name) : Base(std::move(_name)) { }
