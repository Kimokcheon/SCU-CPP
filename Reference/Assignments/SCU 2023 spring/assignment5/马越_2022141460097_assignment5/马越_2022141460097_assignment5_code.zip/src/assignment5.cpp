#include "assignment5.h"

#include <fstream>
#include <algorithm>
#include <fmt/core.h>

static std::vector<Author*> authors;

Dataframe read_csv(std::string filename) {
    std::ifstream file(filename);
    std::string line;
    Dataframe data;
    /// skip header line
    std::getline(file, line);
    auto getCell = [](const std::string &str, int &pos) {
        int start = pos;
        if (str[pos] == '"') {
            ++pos;
            while (str[pos] != '"') {
                ++pos;
            }
            ++pos;
            return str.substr(start + 1, pos - start - 2);
        } else {
            while (str[pos] != ',' && pos < str.size()) {
                ++pos;
            }
            return str.substr(start, pos - start);
        }
    };
    while (std::getline(file, line)) {
        std::vector<std::string> row;
        int pos = 0;
        while (pos < line.size()) {
            row.emplace_back(getCell(line, pos));
            ++pos;
        }
        data.emplace_back(row);
    }
    return data;
}

std::vector<Book> defineBooks(Dataframe* Table) {
    std::vector<Book> books;
    for (auto row : *Table) {
        /// Title,Author,Genre,Price,Publisher
        std::string title = row[0];
        std::string authorName = row[1];
        std::string genre = row[2];
        int pos = row[3].find("$");
        double price = std::stod(row[3].substr(pos + 1));
        std::string publisherName = row[4];
        authors.push_back(new Author(authorName));
        books.emplace_back(title, genre, price, *authors.back(), std::make_shared<Publisher>(publisherName));
    }
    return books;
}

void sortBooksByPrice(std::vector<Book> &list_of_books) {
    std::sort(list_of_books.begin(), list_of_books.end(), [](const Book &a, const Book &b) {
        return a.getPrice() < b.getPrice();
    });
}


void showTable(Dataframe* table,int start, int stop) {
    fmt::print("{:<50} {:<25} {:<25} {:<10} {:<15}\n", "Title", "Author(s)", "Genre", "Price", "Publisher");
    for (int row = start; row < stop; ++row) {
        /// Title,Author,Genre,Price,Publisher
        fmt::print("{:<50} {:<25} {:<25} {:<10} {:<15}\n",
                   table->at(row)[0],
                   table->at(row)[1],
                   table->at(row)[2],
                   table->at(row)[3],
                   table->at(row)[4]);
    }
}