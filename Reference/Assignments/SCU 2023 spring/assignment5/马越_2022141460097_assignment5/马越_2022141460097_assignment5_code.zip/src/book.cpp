#include "book.h"

Book::Book(std::string _title, std::string _genre, double _price, Author &_author,
           std::shared_ptr <Publisher> _publisher):
           title(std::move(_title)), genre(std::move(_genre)), price(_price), author(_author), publisher(std::move(_publisher))
{}

Book &Book::operator=(const Book &other) {
    if (this == &other)
        return *this;
    title = other.title;
    genre = other.genre;
    price = other.price;
    author = other.author;
    publisher = other.publisher;
    return *this;
}

double Book::getPrice() const {
    return price;
}

std::string Book::getAuthorName() const {
    return author.getName();
}

std::string Book::getPublisherName() const {
    return publisher->getName();
}