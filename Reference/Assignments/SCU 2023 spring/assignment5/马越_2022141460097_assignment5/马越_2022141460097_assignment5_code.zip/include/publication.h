#ifndef PUBLICATION_H
#define PUBLICATION_H

#include "base.hpp"

class Publisher: public Base {
public:
    Publisher(std::string _name);
};

#endif //PUBLICATION_H