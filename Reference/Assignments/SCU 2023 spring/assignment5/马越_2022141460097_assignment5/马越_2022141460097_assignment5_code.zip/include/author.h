#ifndef AUTHOR_H
#define AUTHOR_H

#include "base.hpp"

class Author: public Base {
public:
    Author(std::string _name);
};

#endif //AUTHOR_H