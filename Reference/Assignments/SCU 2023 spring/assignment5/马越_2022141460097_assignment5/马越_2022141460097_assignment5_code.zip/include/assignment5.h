#ifndef ASSIGNMENT5_H
#define ASSIGNMENT5_H

#include "publication.h"
#include "author.h"
#include "book.h"

Dataframe read_csv(std::string filename);

std::vector<Book> defineBooks(Dataframe* Table);

void sortBooksByPrice(std::vector<Book> & list_of_books);

void showTable(Dataframe* table,int start, int stop);

#endif //ASSIGNMENT5_H