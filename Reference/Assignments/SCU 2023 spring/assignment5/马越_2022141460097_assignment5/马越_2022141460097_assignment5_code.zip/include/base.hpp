#ifndef ASSIGNMENT5_BASE_HPP
#define ASSIGNMENT5_BASE_HPP

#include <utility>
#include <vector>
#include <string>

typedef std::vector<std::vector<std::string>> Dataframe;

class Book;

class Base {
public:
    Base(std::string _name): name(std::move(_name)) {}
    [[maybe_unused]] void setListOfBooks(std::vector<Book*> all_books) { list_of_books = std::move(all_books); }
    std::string getName() const { return name; }
private:
    std::string name;
    std::vector<Book*> list_of_books;
};

#endif //ASSIGNMENT5_BASE_HPP
