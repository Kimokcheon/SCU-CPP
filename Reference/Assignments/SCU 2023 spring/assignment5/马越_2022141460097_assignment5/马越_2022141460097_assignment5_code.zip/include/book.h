#ifndef BOOK_H
#define BOOK_H

#include "author.h"
#include "publication.h"
#include <memory>
#include <utility>

class Book {
public:
    Book(std::string _title,
         std::string _genre,
         double _price,
         Author& _author,
         std::shared_ptr<Publisher> _publisher);

    Book& operator=(const Book& other);

    double getPrice() const;
    std::string getAuthorName() const;
    std::string getPublisherName() const;

private:
    std::string title;
    std::string genre;
    double price;

    Author& author;
    std::shared_ptr<Publisher> publisher;
};

#endif //BOOK_H