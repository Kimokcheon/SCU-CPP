#include <iostream>

class LinkedList {

public:
    class Node;

    friend std::ostream &operator<<(std::ostream &out, LinkedList::Node &node);

    LinkedList();

    LinkedList(const LinkedList &);

    LinkedList(std::initializer_list<double> list);

    ~LinkedList();

    void push_back(double);

    void push_front(double);

    double pop_back();

    double pop_front();

    double back();

    double front();

    bool empty();

    void clear();

    void show();

    int getSize();

    void extend(const LinkedList &);



    double &operator[](int idx);

    class Node {
        friend double &LinkedList::operator[](int idx);
    public:
        Node();

        explicit Node(double value);

        ~Node();

        double getValue();

        void setValue(double);

    private:
        double value;
    };

public:
    Node *head;
    Node *tail;
private:
    int N{0};
};