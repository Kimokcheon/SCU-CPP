#include "../h/linkedlist.h"

LinkedList::Node::Node() :value(0),next(nullptr), previous(nullptr){}

LinkedList::Node::Node(double _value) : value(_value), next(nullptr), previous(nullptr){}

LinkedList::Node::~Node() = default;

double LinkedList::Node::getValue() {
    return this->value;
}

void LinkedList::Node::setValue(double _value) {
    this->value = _value;
}

LinkedList::LinkedList(): tail(nullptr),head(nullptr){};

LinkedList::LinkedList(const LinkedList & list){
    this->head = nullptr;
    this->tail = nullptr;
    Node *p = list.head;
     while(p != nullptr) {
        push_back(p->getValue());
        p = p->next;
    }
}

LinkedList::LinkedList(std::initializer_list<double> list) {

    this->head = nullptr;
    this->tail = nullptr;
    for(auto i:list){
        this->push_back(i);
    }
}

LinkedList::~LinkedList() = default;

void LinkedList::push_back(double _value) {
    Node *temp = new Node(_value);
    if (this->head == nullptr){
        this->head = temp;
        this->tail = temp;
    }
    else {
        tail->next = temp;
        temp->previous = tail;
        temp->next = nullptr;
        tail = temp;
    }
    N++;
}

void LinkedList::push_front(double _value) {
    Node *temp = new Node(_value);
    if(this->head == nullptr){
        this->head = temp;
        this->tail = temp;
    }
    else {
        head->previous = temp;
        temp->next = this->head;
        temp->previous = nullptr;
        this->head = temp;

    }
    N++;
}

double LinkedList::pop_back() {
    if(this->tail == nullptr)
    {
        throw std::logic_error("Null");
    }
    else {
        double _value = tail->getValue();
        tail = tail->previous;
        delete tail->next;
        tail->next = nullptr;
        N--;
        return _value;
    }
}

double LinkedList::pop_front() {
    if(this->tail == nullptr){
        throw std::logic_error("Null");
    }
    else {
        double _value = tail->getValue();
        head = head->next;
        delete head->previous;
        head->previous = nullptr;
        N--;
        return _value;
    }
}

double LinkedList::back() {
    if(this->tail == nullptr){
        throw std::logic_error("Null");
    }
    else {
        return tail->getValue();
    }
}

double LinkedList::front() {
    if(this->head == nullptr){
        throw std::logic_error("Null");
    }
    else {
        return head->getValue();
    }
}

bool LinkedList::empty() {
    return N == 0;
}

void LinkedList::clear() {
    if(!this->empty()){
        Node *p = head;
        Node *temp;
        while (p != nullptr) {
            temp = p;
            p = p->next;
            delete temp;
        }
        N = 0;
    }
}

void LinkedList::show() {
    Node *p = head;
    while (p != nullptr) {
        std::cout << p->getValue() << " ";
        p = p->next;
    }
    std::cout << std::endl;
}

int LinkedList::getSize() {
    return N;
}

void LinkedList::extend(const LinkedList &_extend) {
    if (tail != nullptr) { tail->next = _extend.head; }
    else {
        head = _extend.head;
        tail = _extend.tail;
        this->N = _extend.N;
        return;
    }
    if (_extend.head != nullptr) { _extend.head->previous = tail; }
    else {
        return;
    }
    tail = _extend.tail;
    this->N += _extend.N;
}

std::ostream &operator<<(std::ostream &out, LinkedList::Node &node) {
    out << node.getValue();
    return out;
}


double & LinkedList::operator[](int i) {
    if(i >= N || i < 0){
        throw std::logic_error("beyond");
    }
    else
    {
        Node *p = this->head;
        while (i-- && p != nullptr) {
            p = p->next;
        }
        return p->value;
    }
}

