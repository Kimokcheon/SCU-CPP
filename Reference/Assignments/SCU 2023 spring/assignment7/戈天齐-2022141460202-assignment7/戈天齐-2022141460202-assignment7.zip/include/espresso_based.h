#ifndef ESPRESSO_BASED_H
#define ESPRESSO_BASED_H
#include <iostream>
#include "ingredient.h"
#include <vector>
class EspressoBased
{
public:
    virtual std::string get_name() = 0;
    virtual double price() = 0;

    void brew();
    std::vector<Ingredient*>& get_ingredients();
    //更改为定义为虚析构函数


protected:
    EspressoBased();
    EspressoBased(const EspressoBased& esp);
    void operator=(const EspressoBased& esp);
    virtual ~EspressoBased();

    std::vector<Ingredient*> ingredients;
    std::string name;

};
#endif // ESPRESSO_BASED_H