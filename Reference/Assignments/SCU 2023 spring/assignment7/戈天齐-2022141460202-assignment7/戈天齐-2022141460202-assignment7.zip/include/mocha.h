#ifndef MCOHA_H
#define MCOHA_H
#include "espresso_based.h"
#include "sub_ingredients.h"
class Mocha : public EspressoBased
{
public:

    Mocha();
    Mocha(const Mocha& cap);
    ~Mocha();
    //为什么是void
    void operator=(const Mocha& cap);
    //这个为什么要声明为虚函数
    virtual std::string get_name();
    virtual double price();

    void add_side_item(Ingredient* side);
    std::vector<Ingredient*>& get_side_items();

private:
    std::vector<Ingredient*> side_items;

};
#endif // MCOHA_H