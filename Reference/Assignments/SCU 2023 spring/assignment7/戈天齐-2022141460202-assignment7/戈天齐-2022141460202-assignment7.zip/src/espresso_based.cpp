#include <cstring>
#include "sub_ingredients.h"
#include "espresso_based.h"
std::vector<Ingredient*>& EspressoBased::get_ingredients() {
    return ingredients;
}

EspressoBased::EspressoBased()  = default;

EspressoBased::~EspressoBased() {
    for(const auto& i : ingredients)
        delete i;
    ingredients.clear();
    std::cout << "EspressoBased destructor called" << std::endl;
}

EspressoBased::EspressoBased(const EspressoBased &esp) {
    name = esp.name;
    //ingredients = esp.ingredients;
    //上述实现是一个浅拷贝实现，会导致两个对象的ingredients里面的元素指针指向同一个地址
//    for(const auto i : ingredients){
//        Ingredient *temp = new Ingredient(*i); 抽象类无法作为类型
//        ingredients.push_back(temp);
//    }
    if(name == std::string("Cappuccino")){
        Ingredient* espresso = new Espresso(2);
        this->ingredients.push_back(espresso);
        Ingredient* milk = new Milk(2);
        this->ingredients.push_back(milk);
        Ingredient* milkfoam = new MilkFoam(1);
        this->ingredients.push_back(milkfoam);
    }
    else{
        Ingredient* espresso = new Espresso(2);
        this->ingredients.push_back(espresso);
        Ingredient* milk = new Milk(2);
        this->ingredients.push_back(milk);
        Ingredient* milkfoam = new MilkFoam(1);
        this->ingredients.push_back(milkfoam);
        Ingredient* chocolate = new Chocolate(1);
        this->ingredients.push_back(chocolate);
    }
}
//左值呢
void EspressoBased::operator=(const EspressoBased& esp){
    this->ingredients = esp.ingredients;
    //this->ingredients = esp.get_ ?哪一种
    name = esp.name;
}