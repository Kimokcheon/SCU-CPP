#include "cappuccino.h"
Cappuccino::Cappuccino(){
    this->name = "Cappuccino";
    Ingredient* espresso = new Espresso(2);
    this->ingredients.push_back(espresso);
    Ingredient* milk = new Milk(2);
    this->ingredients.push_back(milk);
    Ingredient* milkfoam = new MilkFoam(1);
    this->ingredients.push_back(milkfoam);

}

Cappuccino::Cappuccino(const Cappuccino &cap) : EspressoBased(cap){
    for(const auto i : cap.side_items){
        Ingredient *temp = i->clone();
        this->side_items.push_back(temp);
    }
//    for( auto i : cap.ingredients){
//        Ingredient *temp;
//        temp = reinterpret_cast<Ingredient *>(new decltype(i));
//        *temp = *i;
//        this->ingredients.push_back(temp);
//    }

}

Cappuccino::~Cappuccino() {
    //这里会调用基类的析构函数吗
    for(const auto& i : side_items)
        delete i;
    side_items.clear();
    std::cout << "Cappuccino destructor called" << std::endl;
}
//为什么void还能实现赋值
void Cappuccino::operator=(const Cappuccino& cap){
    this->name = cap.name;
    //存左值
    std::vector<Ingredient*> temp_ing_l = this->ingredients;
    std::vector<Ingredient*> temp_side_l = this->side_items;
    //存右值
    std::vector<Ingredient*> temp_ing_r = cap.ingredients;
    std::vector<Ingredient*> temp_side_r = cap.side_items;

    //清空左值,但没有释放内存
    this->ingredients.clear();
    this->side_items.clear();
    //深拷贝右值
    for(auto const& i : temp_ing_r){
        Ingredient *temp = i->clone();
        this->ingredients.push_back(temp);
    }
    for(auto const& i : temp_side_r){
        Ingredient *temp = i->clone();
        this->side_items.push_back(temp);
    }
    //释放左值内存
    for(const auto& i : temp_ing_l)
        delete i;
    temp_ing_l.clear();
    for(const auto& i : temp_side_l)
        delete i;
    temp_side_l.clear();
}

 std::string Cappuccino::get_name(){
    return name;
}

double Cappuccino::price()
{
    double sum = 0;
    for(const auto i : ingredients){
        sum += i->price();
    }
    for(const auto i:side_items){
        sum += i->price();
    }
    return sum;
}

void Cappuccino::add_side_item(Ingredient *side) {
    side_items.push_back(side);
}

std::vector<Ingredient*>& Cappuccino::get_side_items() {
    return side_items;
}