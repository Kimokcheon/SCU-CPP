#include "mocha.h"
Mocha::Mocha(){
    this->name = "Mocha";
    Ingredient* espresso = new Espresso(2);
    this->ingredients.push_back(espresso);
    Ingredient* milk = new Milk(2);
    this->ingredients.push_back(milk);
    Ingredient* milkfoam = new MilkFoam(1);
    this->ingredients.push_back(milkfoam);
    Ingredient* chocolate = new Chocolate(1);
    this->ingredients.push_back(chocolate);
}

Mocha::Mocha(const Mocha &cap) : EspressoBased(cap){
    for(const auto i : cap.side_items){
        Ingredient *temp = i->clone();
        this->side_items.push_back(temp);
    }
}

Mocha::~Mocha() {
    //这里会调用基类的析构函数吗
    for(const auto& i : side_items)
        delete i;
    side_items.clear();
}

void Mocha::operator=(const Mocha& cap){
    this->ingredients = cap.ingredients;
    this->name = cap.name;
    this->side_items = cap.side_items;
}

std::string Mocha::get_name(){
    return name;
}

double Mocha::price()
{
    double sum = 0;
    for(const auto i : ingredients){
        sum += i->price();
    }
    for(const auto i:side_items){
        sum += i->price();
    }
    return sum;
}

void Mocha::add_side_item(Ingredient *side) {
    side_items.push_back(side);
}

std::vector<Ingredient*>& Mocha::get_side_items() {
    return side_items;
}